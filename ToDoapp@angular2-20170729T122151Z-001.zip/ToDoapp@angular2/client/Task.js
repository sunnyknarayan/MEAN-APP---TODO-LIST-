"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Task = (function () {
    function Task() {
    }
    return Task;
}());
exports.Task = Task;
//# sourceMappingURL=Task.js.map